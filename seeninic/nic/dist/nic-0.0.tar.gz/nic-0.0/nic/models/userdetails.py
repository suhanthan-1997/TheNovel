from sqlalchemy import (
    Column,
    Index,
    Integer,
    Text,
)

from .meta import Base


class userdetails(Base):
	__tablename__ = 'userdetails'
	id = Column(Text,  primary_key=True)
	firstname = Column(Text)
	designation = Column(Text)
	placeofposting = Column(Text)
	spouseinworking = Column(Text)
	rentedhouse = Column(Text)
	annualsalary = Column(Integer)
	otherincome = Column(Integer)
	transportallowance = Column(Integer)
	incomefromhouse = Column(Integer)
	grosstotal = Column(Integer)
	protaxpaid = Column(Integer)


Index('my_index', userdetails.id, unique=True, mysql_length=255)
