from sqlalchemy import (
    Column,
    Index,
    Integer,
    Text,
)

from .meta import Base


class login(Base):
    __tablename__ = 'login'
    id = Column(Text,  primary_key=True)
    password = Column(Integer)


Index('my_index', login.id, unique=True, mysql_length=255)
