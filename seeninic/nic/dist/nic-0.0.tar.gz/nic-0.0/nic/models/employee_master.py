from sqlalchemy import (
    Column,
    Index,
    Integer,
    Text,
)

from .meta import Base


class employee_master(Base):
    __tablename__ = 'employee_master'
    empid = Column(Text,  primary_key=True)
    empname = Column(Text)
    fathername = Column(Text)
    empaddress = Column(Text)
    empgender = Column(Text)
    empmaritialstatus = Column(Text)

Index('my_index', employee_master.empid, unique=True, mysql_length=255)
