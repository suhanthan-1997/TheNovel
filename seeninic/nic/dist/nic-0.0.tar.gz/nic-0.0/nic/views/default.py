from pyramid.response import Response
from pyramid.view import view_config

from sqlalchemy.exc import DBAPIError

from ..models import login
from ..models import userdetails
from ..models import employee_master

from pyramid.httpexceptions import HTTPForbidden 
	

@view_config(route_name='home', renderer='../templates/pages/page1.pt')
def my_view1(request):
   # try:
    #    query = request.dbsession.query(MyModel)
     #   one = query.filter(MyModel.name == 'one').first()
   # except DBAPIError:
    #    return Response(db_err_msg, content_type='text/plain', status=500)
    return {}

@view_config(route_name='page2', renderer='../templates/pages/page2.pt')
def login2(request):
	username = request.params['username']
	pswd = request.params['pswd']
	#new_login = login(id=username, password=pswd)	
	#request.dbsession.add(new_login)
	#return Response("success")
	name = request.dbsession.query(login).filter(login.id == username,login.password == pswd).first()	
	if name is None:
		raise HTTPForbidden		
	return {'user':username}

@view_config(route_name='page3', renderer='../templates/pages/page3.pt')
def login3(request):
    return {}

@view_config(route_name='page4', renderer='../templates/pages/page4.pt')
def login4(request):
	#print('\n\n\n' + request.params['work'])
	#print('\n\n\n' + request.params['work'])	
	return {}

@view_config(route_name='page5', renderer='../templates/pages/page5.pt')
def login5(request):
    return {}

@view_config(route_name='page6', renderer='../templates/pages/page6.pt')
def login6(request):
    #try:
    #    one = DBSession.query(MyModel).filter(MyModel.name == 'one').first()
    #except DBAPIError:
    #    return Response(conn_err_msg, content_type='text/plain', status_int=500)
    return {}

@view_config(route_name='page6a', renderer='../templates/pages/page6a.pt')
def login6a(request):
    return {}

@view_config(route_name='page6c', renderer='../templates/pages/page6c.pt')
def login6c(request):
    return {}
	
@view_config(route_name='page6d', renderer='../templates/pages/page6d.pt')
def login6d(request):
    return {}

@view_config(route_name='page6e', renderer='../templates/pages/page6e.pt')
def login6e(request):
    return {}

@view_config(route_name='page6f', renderer='../templates/pages/page6f.pt')
def login6f(request):
    return {}

@view_config(route_name='page6g', renderer='../templates/pages/page6g.pt')
def login6g(request):
    return {}

@view_config(route_name='page6h', renderer='../templates/pages/page6h.pt')
def login6h(request):
    return {}

@view_config(route_name='page6i', renderer='../templates/pages/page6i.pt')
def login6i(request):
    return {}

@view_config(route_name='page6k', renderer='../templates/pages/page6k.pt')
def login6k(request):
    return {}

@view_config(route_name='page6l', renderer='../templates/pages/page6l.pt')
def login6l(request):
    return {}

@view_config(route_name='page6m', renderer='../templates/pages/page6m.pt')
def login6m(request):
    return {}

@view_config(route_name='finalpage', renderer='../templates/pages/finalpage.pt')
def loginfinal(request):
    return {}


db_err_msg = """\
Pyramid is having a problem using your SQL database.  The problem
might be caused by one of the following things:

1.  You may need to run the "initialize_nic_db" script
    to initialize your database tables.  Check your virtual
    environment's "bin" directory for this script and try to run it.

2.  Your database server may not be running.  Check that the
    database server referred to by the "sqlalchemy.url" setting in
    your "development.ini" file is running.

After you fix the problem, please restart the Pyramid application to
try it again.
"""
